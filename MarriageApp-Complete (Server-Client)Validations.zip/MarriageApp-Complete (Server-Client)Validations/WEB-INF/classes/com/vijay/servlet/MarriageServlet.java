package com.vijay.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MarriageServlet extends HttpServlet{
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw=null;
		String name=null,gender=null,tage=null,flag=null;
		int age=0;
		List<String> errlist=null;
		//get writer from response object
		pw=res.getWriter();
		//set content type
		res.setContentType("text/html");
		//get parameter values
		name=req.getParameter("name");
		tage=req.getParameter("age");
		gender=req.getParameter("gender");
		flag=req.getParameter("vFlag");

		
		
		//perfoming form validation at server side
		if(flag.equalsIgnoreCase("NO")) {
			
			errlist= new ArrayList();

		System.out.println("***** Server side validation ******");
		
				if(name==null || name.isEmpty() ||  name.length()==0) {
					errlist.add("<h1 style='color:red'> *Name is required </h1>");
					}
			   if(tage.isEmpty()) {
					errlist.add("<h1 style='color:red'> *Age is required </h1>");
				}
				
				try {
					age=Integer.parseInt(tage);
					if(age<=0 || age>125) {
						errlist.add("<h1 style='color:red'> *Age must be between(1-125)</h1>");
					}
				}
				catch(NumberFormatException nef) {
					errlist.add("<h1 style='color:red'> *Age must be number only</h1>");
				}
				//for each loop to display the collected errors
				if(errlist.size()!=0) {
					for(String ermsg:errlist) {
						pw.println("<center>");
						pw.println(ermsg);
						pw.println("</center>");
						return;
					}
				}
		}//if	
		else {
			age=Integer.parseInt(tage);		//if server side validations are not done age must be converted to number
		}
		
		//build business logic
		pw.println("<center>");

		if(gender.equalsIgnoreCase("m")) {
			if(age>21) {
				pw.println("<h1 style='color:green' > Mr."+name + " is Eligible, Congrats!</h1> ");
			}
			else { 
				pw.println("<h1 style='color:red' > Mr."+name + " is NOT Eligible, Get a Job!</h1>" );
			}
		}
		else if(gender.equalsIgnoreCase("f")) {
			if(age>18) {
				pw.println("<h1 style='color:green' > Ms."+name + " is Eligible, Congrats!</h1>" );
			}
			else { 
				pw.println("<h1 style='color:red' > Ms."+name + " is NOT Eligible, Get a Job!</h1>" );
			}
		}
		pw.println("</center>");
		//create hyperlink
		pw.println("<center><a href='input.html'> <img src='home.jpg' width='50' height='50'><br>Home</a></center>");

	}

}
