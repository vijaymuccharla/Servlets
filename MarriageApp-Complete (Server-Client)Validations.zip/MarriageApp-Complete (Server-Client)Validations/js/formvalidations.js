
function validateForm(frm) {
	//declare variables for the inputs
	var name, age;
	var alpha= /^[0-9]+$/;
	name = frm.name.value;
	age = frm.age.value;

	//set flag variable of hidden attribute to "yes" indicating client side validations are done
	document.getElementById("flag").value="yes";

	//validations using alert boxes
	alert("***** Client side form validations *****");		//just for records

	//empty the paragraph attribute to erase last ERROR MESG
	document.getElementById("p1").innerHTML="";
	document.getElementById("p2").innerHTML="";




	/* 			if (name == "") {
				alert("Name cannot be empty");
				frm.name.focus();
				return false;
			}
			if (age == "") {
				alert("Age cannot be empty");
				frm.age.focus();
				return false;
			} else if (isNaN(age)) {
				alert("Age must be number only");
				frm.age.focus();
				return false;
			} else if (age<=0 || age>125) {
				alert("Age must be between 1 to 125");
				frm.age.focus();
				return false;
			}
			return true;
	 */
	//form validation using innerHTML

	if (name == "") {
		document.getElementById("p1").innerHTML="*Name is required";
		frm.name.focus();
		return false;
	}
	else if(name.match(alpha)){
		document.getElementById("p1").innerHTML="*Name cannot contain numbers";
		frm.name.focus();
		return false;
	}


	if (age == "") {
		document.getElementById("p2").innerHTML="*Age is required";
		frm.age.focus();
		return false;
	}
	else if (isNaN(age)) {
		document.getElementById("p2").innerHTML="*Age must be numeric";
		frm.age.focus();
		return false;
	} else if (age<=0 || age>125) {
		document.getElementById("p2").innerHTML="*Age must be between 1-125 only";
		frm.age.focus();
		return false;
	}
	return true;
}	